figureS1d_1_chicago
Manuscript asset: partition_1_chicago.pdf

Run from this folder: python draw.py
Or from the package root: python figures/figureS1d_1_chicago/draw.py
Dependencies: NumPy, pandas, Matplotlib (see ../requirements.txt).
Inputs: the local raw_data folder. Outputs: figure.pdf and figure.png (600 dpi), in this folder.
Running again overwrites these two generated outputs. The supplied code and data are unchanged from the October 14 figure package.
